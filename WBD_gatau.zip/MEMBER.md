13511043 "Mohamad Rivai Ramandhani" "13511043@std.stei.itb.ac.id" "vai03"
13511063 "Renusa Andra Prayogo" "13511063@std.stei.itb.ac.id" "andra49"
13511071 "Setyo Legowo" "13511071@std.stei.itb.ac.id" "taktyongslind"